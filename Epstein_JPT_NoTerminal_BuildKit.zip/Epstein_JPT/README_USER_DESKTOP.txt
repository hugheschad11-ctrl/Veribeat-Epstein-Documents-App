Epstein JPT (Desktop)

What this is
- A local, offline search app for your Epstein/EFTA PDFs.
- No terminal required for end users.

How to use (end user)
1) Put PDFs into the 'docs' folder next to Epstein JPT.exe
   Example: docs/EFTA00014312.pdf

2) Double-click Epstein JPT.exe

3) Search. Double-click a result to open the PDF (if present).

Notes
- This app does NOT attempt to reveal redacted content.
- Results cite the filename + page number.

