import os
import sqlite3
from dataclasses import dataclass
from typing import List, Optional

@dataclass
class Hit:
    file: str
    page: Optional[int]
    snippet: str
    score: float

def _connect(db_path: str) -> sqlite3.Connection:
    con = sqlite3.connect(db_path)
    con.row_factory = sqlite3.Row
    return con

def search(db_path: str, query: str, top: int = 25) -> List[Hit]:
    """
    Search the local SQLite FTS index.
    Assumes a virtual table named `docs_fts` with columns:
      file, page, text
    """
    if not query or not query.strip():
        return []
    con = _connect(db_path)
    try:
        # Prefer bm25 if available
        sql = """
        SELECT file, page,
               snippet(docs_fts, 2, '⟦', '⟧', ' … ', 16) AS snippet,
               bm25(docs_fts) AS score
        FROM docs_fts
        WHERE docs_fts MATCH ?
        ORDER BY score
        LIMIT ?;
        """
        rows = con.execute(sql, (query, top)).fetchall()
    except sqlite3.OperationalError:
        # Fallback without bm25/snippet
        sql = """
        SELECT file, page, substr(text, 1, 280) AS snippet, 0.0 AS score
        FROM docs_fts
        WHERE docs_fts MATCH ?
        LIMIT ?;
        """
        rows = con.execute(sql, (query, top)).fetchall()
    finally:
        con.close()
    hits=[]
    for r in rows:
        hits.append(Hit(
            file=str(r["file"]),
            page=(int(r["page"]) if r["page"] is not None and str(r["page"]).isdigit() else None),
            snippet=str(r["snippet"]).replace('\n',' '),
            score=float(r["score"]) if "score" in r.keys() else 0.0
        ))
    return hits

def get_db_path() -> str:
    return os.environ.get("EPSTEIN_JPT_DB", os.path.join(os.path.dirname(__file__), "epstein_index.sqlite"))
