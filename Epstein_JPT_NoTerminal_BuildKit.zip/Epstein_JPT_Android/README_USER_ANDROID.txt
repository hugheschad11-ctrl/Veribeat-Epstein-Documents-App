Epstein JPT (Android - Sideload)

Install (user)
1) Copy the APK to your phone.
2) Settings -> Security/Privacy -> Allow unknown apps for your file manager/browser.
3) Tap the APK to install.

Use
- Put your PDFs somewhere on the phone (e.g., Downloads/EpsteinJPT/docs).
- In the app, choose the docs folder once, then search and open PDFs.

Notes
- This build is a debug-signed APK suitable for sideloading.
- This app does NOT attempt to reveal redacted content.
